using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
[CreateAssetMenu(menuName="Items/Pocion Mega Vida")]
public class ItemMegaVida : InventarioItem
{
    [Header("Pocion info")]
    public float Megarestauracion;
}